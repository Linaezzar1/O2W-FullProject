import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-choixpayement',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './choixpayement.component.html',
  styleUrl: './choixpayement.component.css'
})
export class ChoixpayementComponent {

}
