import { Component } from '@angular/core';

@Component({
  selector: 'app-partnership',
  standalone: true,
  imports: [],
  templateUrl: './partnership.component.html',
  styleUrl: './partnership.component.css'
})
export class PartnershipComponent {

}
