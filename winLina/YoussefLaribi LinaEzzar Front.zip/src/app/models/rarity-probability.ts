import { Rarity } from "./rarity";

export class rarityProbabilities {
    constructor(
        public rarity: Rarity,  
        public probability: number,
      ) {}
    
}
